/******************************************************************
Copyright © Deng Zhimao Co., Ltd. 1990-2030. All rights reserved.
* @projectName   aflex
* @brief         dac.cpp
* @author        Deng Zhimao
* @email         1252699831@qq.com
* @date          2020-07-31
*******************************************************************/
#include "dac.h"
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <QDebug>

Dac::Dac(QObject *parent) : QObject (parent)
{
#if __arm__
    system("echo 0 > /sys/devices/platform/soc/40017000.dac/40017000.dac:dac@1/iio:device1/out_voltage1_powerdown");
#endif
}

void Dac::setDac(QString dac)
{
    char const *filename = "/sys/devices/platform/soc/40017000.dac/40017000.dac:dac@1/iio:device1/out_voltage1_raw";
    int err = 0;
    int fd;
    QByteArray ba;
    ba = dac.toLatin1();
    char *buf = ba.data();

    fd = open(filename, O_RDWR);
    if(fd < 0){
        close(fd);
        qDebug()<<"open file error!"<<endl;
        return;
    }

    err = write(fd, buf, sizeof(buf));
    if (err < 0){
        close(fd);
        qDebug()<<"read data error!"<<endl;
        return;
    }
    close(fd);
}

Dac::~Dac()
{

}
