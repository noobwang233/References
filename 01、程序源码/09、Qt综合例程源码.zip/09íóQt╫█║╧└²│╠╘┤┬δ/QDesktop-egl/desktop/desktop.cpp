/******************************************************************
Copyright © Deng Zhimao Co., Ltd. 1990-2030. All rights reserved.
* @projectName   desktop
* @brief         desktop.cpp
* @author        Deng Zhimao
* @email         1252699831@qq.com
* @date          2020-07-31
*******************************************************************/
#include "desktop.h"
#include <QDebug>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
MyDesktop::MyDesktop(QObject *parent) : QObject (parent)
{
#ifdef __arm__
    getSystemVolume();
#endif
}

MyDesktop::~MyDesktop()
{

}

void MyDesktop::timerInit()
{
    timer = new QTimer();
    connect(timer, SIGNAL(timeout()), this, SLOT(getCpuTemp()));
#ifdef __arm__
    timer->start(1000);
#endif
}

void MyDesktop::systemReboot()
{
    system("reboot");
    //system("kill -9 $(pidof QDesktop)");
}

void MyDesktop::systemPoweroff()
{
    system("poweroff");
    //system("kill -9 $(pidof QDesktop)");
}

QString MyDesktop::sysVolume()
{
    return sysvolume;
}
void MyDesktop::getSystemVolume()
{
#ifdef __arm__
    myProcess = new QProcess;
    connect(myProcess,&QProcess::readyReadStandardOutput,this,&MyDesktop::standardOutput_ReadVolume);
    system("return=$(amixer -c  STM32MP1DK  cget name='PCM Playback Volume' |grep -E ': values=' |awk '{print $2}');echo ${return#*,} >./volume.tmp");
    myProcess->start("cat ./volume.tmp");
    myProcess->waitForStarted();
#endif
}

void MyDesktop::setSystemVolume(QString value)
{
#ifdef __arm__
    QString cmdStr = tr("amixer -c STM32MP1DK cset name='PCM Playback Volume' '%1','%1'").arg(value);
    system(cmdStr.toStdString().c_str());
#endif
}

void MyDesktop::standardOutput_ReadVolume()
{
    sysvolume = myProcess->readAllStandardOutput();
    sysvolume.remove(QChar('\n'), Qt::CaseInsensitive);
    emit sysVolumeChanged();
}

QString MyDesktop::cpuTemp()
{
    return cputemp;
}

QString MyDesktop::readCpuTemp()
{
    char const *filename = "/sys/class/hwmon/hwmon0/temp1_input";
    int err = 0;
    int fd;
    char buf[10];

    fd = open(filename, O_RDONLY);
    if(fd < 0){
        close(fd);
        timer->stop();
        return "open file error!";
    }

    err = read(fd, buf, sizeof(buf));
    if (err < 0){
        timer->stop();
        close(fd);
        return "read data error!";
    }
    close(fd);

    QString tempValue = buf;
    QStringList list = tempValue.split("\n");
    return list[0];
}

void MyDesktop::getCpuTemp()
{
    cputemp = readCpuTemp();
    double temp_data = cputemp.toDouble() / 1000;
    cputemp = QString::number(temp_data,'f',2);
    emit cpuTempChanged();
}
