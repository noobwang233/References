/******************************************************************
Copyright © Deng Zhimao Co., Ltd. 1990-2021. All rights reserved.
* @projectName   05_opencv_camera
* @brief         camera.cpp
* @author        Deng Zhimao
* @email         1252699831@qq.com
* @net           www.openedv.com
* @date          2021-03-17
*******************************************************************/
#include "camera.h"

/* opencv4 */
#if __arm__
#include "opencv4/opencv2/core/core.hpp"
#include "opencv4/opencv2/highgui/highgui.hpp"
/* CV_CAP_PROP_FRAME_WIDTH这样的宏在此头文件里 */
#include "opencv4/opencv2/videoio/legacy/constants_c.h"
#else
/* Ubuntu18上使用的opencv3，头文件路径 */
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#endif

#include <QImage>
#include <QDebug>

Camera::Camera(QObject *parent) :
    QObject(parent)
{
    /* 实例化 */
    capture = new cv::VideoCapture();
    timer = new QTimer(this);

    /* 信号槽连接 */
    connect(timer, SIGNAL(timeout()), this, SLOT(timerTimeOut()));
}

Camera::~Camera()
{
    delete capture;
    capture = NULL;
}

void Camera::selectCameraDevice(int index)
{
    /* 如果有其他摄像头打开了，先释放 */
    if (capture->isOpened()) {
        capture->release();
    }

    /* 打开摄像头设备 */
    capture->open(index);

    /* 设置采集摄像头的分辨率的宽度 */
    capture ->set(CV_CAP_PROP_FRAME_WIDTH, 640);

    /* 设置采集摄像头的分辨率的高度 */
    capture ->set(CV_CAP_PROP_FRAME_HEIGHT, 480);

    /* 设置亮度 */
    capture ->set(CV_CAP_PROP_BRIGHTNESS, 1);

    /* 设置曝光 */
    capture ->set(CV_CAP_PROP_EXPOSURE, -7);

    /* 设置对比度 */
    capture ->set(CV_CAP_PROP_CONTRAST, 60);
}

bool Camera::cameraProcess(bool bl)
{
    if (bl) {
        /* 为什么是33？1000/33约等于30帧，也就是一秒最多显示30帧  */
        timer->start(33);
    } else {
        timer->stop();
    }
    /* 返回摄像头的状态 */
    return capture->isOpened();
}

void Camera::timerTimeOut()
{
    /* 如果摄像头没有打开，停止定时器，返回 */
    if (!capture->isOpened()) {
        timer->stop();
        return;
    }

    static cv::Mat frame;
    *capture >> frame;
    if (frame.cols)
        /* 发送图片信号 */
        emit readyImage(matToQImage(frame));
}

QImage Camera::matToQImage(const cv::Mat &img)
{
    /* USB摄像头和OV5640等都是RGB三通道，不考虑单/四通道摄像头 */
    if(img.type() == CV_8UC3) {
        /* 得到图像的的首地址 */
        const uchar *pimg = (const uchar*)img.data;

        /* 以img构造图片 */
        QImage qImage(pimg, img.cols, img.rows, img.step,
                      QImage::Format_RGB888);

        /* 在不改变实际图像数据的条件下，交换红蓝通道 */
        return qImage.rgbSwapped();
    }

    /* 返回QImage */
    return QImage();
}
